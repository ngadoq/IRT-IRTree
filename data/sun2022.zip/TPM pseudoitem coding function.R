PseudoCoding <- function(Data,Lower,Upper){
  
  #function to recode Likert items to pseudoitems for item response process tree model
  #the 'Data' argument is the response matrix
  #the 'Lower' argument is the lower bound of response options (e.g., 1 for a 5-point Likert scale of 1 to 5)
  #the 'Upper' argument is the upper bound of response options (e.g., 5 for a 5-point Likert scale of 1 to 5)
  #function outputs a list of recoded pseudoitems of midpoint (for odd number of response options), extremity, and direction
  
  m <- nrow(Data)
  n <- ncol(Data) 
  Mid <- (Lower+Upper)/2
  M <- matrix(NA,nrow = m,ncol = n)
  E <- matrix(NA,nrow = m,ncol = n)
  D <- matrix(NA,nrow = m,ncol = n)
  
  for (i in 1:n) {
    for (k in 1:m) {
      if (is.na(Data[k,i])) {
        M[k,i] <- NA
        E[k,i] <- NA
        D[k,i] <- NA
      }
	  
      else if (Data[k,i]==Mid) {
        M[k,i] <- 1
        E[k,i] <- NA
        D[k,i] <- NA  
      }
	  
      else if (Data[k,i]==Lower) {
        M[k,i] <- 0
        E[k,i] <- 1
        D[k,i] <- 0
      }
	  
      else if (Data[k,i]==Upper) {
        M[k,i] <- 0
        E[k,i] <- 1
        D[k,i] <- 1
      }
	  
      else if (Data[k,i]>Mid) {
        M[k,i] <- 0
        E[k,i] <- 0
        D[k,i] <- 1
      }
	  
      else {
        M[k,i] <- 0
        E[k,i] <- 0
        D[k,i] <- 0
      }
    }
  }
  return(list(M,E,D))
}
