# Mplus files

- The files ending with `01` pertain to the multiple-group models for 11 countries.
- The files ending with `11` pertain to the models for Venezuela.
- The data are stored in file `mplus-tree-mcn-01.txt`.

